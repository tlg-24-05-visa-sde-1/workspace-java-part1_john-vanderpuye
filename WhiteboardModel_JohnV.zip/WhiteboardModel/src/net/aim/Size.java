package net.aim;

public enum Size {
    SMALL, MEDIUM, LARGE
}